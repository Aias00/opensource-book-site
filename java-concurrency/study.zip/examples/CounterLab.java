import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class CounterLab {
    private static int unsafe;
    private static final AtomicInteger safe = new AtomicInteger();

    public static void main(String[] args) throws InterruptedException {
        int threads = 4, loops = 100_000;
        CountDownLatch start = new CountDownLatch(1);
        Thread[] workers = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            workers[i] = new Thread(() -> {
                try {
                    start.await();
                    for (int j = 0; j < loops; j++) {
                        unsafe++;
                        safe.incrementAndGet();
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            workers[i].start();
        }
        start.countDown();
        for (Thread worker : workers) worker.join();
        System.out.println("期望=" + threads * loops);
        System.out.println("普通=" + unsafe + "，原子=" + safe.get());
        if (safe.get() != threads * loops) throw new AssertionError();
    }
}

import java.util.concurrent.*;

public class QueueLab {
    public static void main(String[] args) throws Exception {
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(2);
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            Future<Integer> consumer = pool.submit(() -> {
                int sum = 0;
                while (true) {
                    int value = queue.take();
                    if (value == -1) return sum;
                    sum += value;
                }
            });
            Future<?> producer = pool.submit(() -> {
                try {
                    for (int i = 1; i <= 5; i++) queue.put(i);
                    queue.put(-1);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException(e);
                }
            });
            producer.get(5, TimeUnit.SECONDS);
            int sum = consumer.get(5, TimeUnit.SECONDS);
            System.out.println("合计=" + sum);
            if (sum != 15) throw new AssertionError();
        } finally {
            pool.shutdownNow();
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) throw new AssertionError();
        }
    }
}

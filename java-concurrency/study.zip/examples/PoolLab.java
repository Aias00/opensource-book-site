import java.util.concurrent.*;

public class PoolLab {
    public static void main(String[] args) throws Exception {
        CountDownLatch release = new CountDownLatch(1);
        ThreadPoolExecutor pool = new ThreadPoolExecutor(
            2, 4, 30, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(2),
            Executors.defaultThreadFactory(),
            new ThreadPoolExecutor.AbortPolicy());
        Runnable task = () -> {
            try { release.await(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        };
        int accepted = 0, rejected = 0;
        try {
            for (int i = 0; i < 7; i++) {
                try { pool.execute(task); accepted++; }
                catch (RejectedExecutionException e) { rejected++; }
            }
            System.out.println("接收=" + accepted + "，拒绝=" + rejected);
            System.out.println("线程=" + pool.getPoolSize()
                + "，排队=" + pool.getQueue().size());
            if (accepted != 6 || rejected != 1) throw new AssertionError();
        } finally {
            release.countDown();
            pool.shutdown();
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
                pool.shutdownNow();
                throw new AssertionError("线程池未及时结束");
            }
        }
    }
}

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class StockLab {
    static final class Stock {
        private int remaining = 100;
        synchronized boolean buy() {
            if (remaining == 0) return false;
            remaining--;
            return true;
        }
        synchronized int remaining() { return remaining; }
    }
    public static void main(String[] args) throws Exception {
        Stock stock = new Stock();
        AtomicInteger sold = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(8);
        Future<?>[] tasks = new Future<?>[1000];
        try {
            for (int i = 0; i < tasks.length; i++) {
                tasks[i] = pool.submit(() -> {
                    if (stock.buy()) sold.incrementAndGet();
                });
            }
            for (Future<?> task : tasks) task.get();
        } finally {
            pool.shutdown();
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) pool.shutdownNow();
        }
        System.out.println("售出=" + sold.get() + "，剩余=" + stock.remaining());
        if (sold.get() != 100 || stock.remaining() != 0) throw new AssertionError();
    }
}

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class VirtualLab {
    public static void main(String[] args) throws Exception {
        Semaphore permits = new Semaphore(3);
        AtomicInteger active = new AtomicInteger();
        AtomicInteger peak = new AtomicInteger();
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Future<?>> futures = new ArrayList<>();
            for (int i = 0; i < 20; i++) {
                futures.add(executor.submit(() -> {
                    boolean acquired = false;
                    try {
                        permits.acquire();
                        acquired = true;
                        int now = active.incrementAndGet();
                        try {
                            peak.accumulateAndGet(now, Math::max);
                            Thread.sleep(20); // 模拟等待外部服务
                        } finally { active.decrementAndGet(); }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException(e);
                    } finally {
                        if (acquired) permits.release();
                    }
                }));
            }
            for (Future<?> future : futures) future.get();
        }
        System.out.println("最大同时调用=" + peak.get());
        if (peak.get() > 3 || active.get() != 0) throw new AssertionError();
    }
}

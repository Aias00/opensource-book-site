public class Hello {
    public static void main(String[] args) throws Exception {
        Thread worker = new Thread(() ->
            System.out.println("工作线程：" + Thread.currentThread().getName()));
        worker.start();
        worker.join();
        System.out.println("主线程：工作完成");
    }
}

配套代码需要 JDK 21。编译：javac -encoding UTF-8 examples/*.java
运行示例：java -cp examples CounterLab
其他入口：Hello、StockLab、PoolLab、QueueLab、VirtualLab。
